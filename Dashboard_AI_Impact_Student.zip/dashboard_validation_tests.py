
from pathlib import Path
import pandas as pd

DATA_PATH = Path("data/clean_dataset_ai_student_impact.csv")
VALID_YEARS = {"Freshman", "Sophomore", "Junior", "Senior", "Graduate"}


def main() -> None:
    df = pd.read_csv(DATA_PATH)
    checks = []
    checks.append(("dataset_exists", DATA_PATH.exists()))
    checks.append(("row_count_positive", len(df) > 0))
    checks.append(("student_id_unique", df["Student_ID"].astype(str).is_unique))
    checks.append(("year_valid", df["Year_of_Study"].isin(VALID_YEARS).all()))
    checks.append(("pre_gpa_range", df["Pre_Semester_GPA"].between(0, 4).all()))
    checks.append(("post_gpa_range", df["Post_Semester_GPA"].between(0, 4).all()))
    checks.append(("tool_diversity_range", df["Tool_Diversity"].between(1, 5).all()))
    checks.append(("no_missing_critical", df[["Post_Semester_GPA", "Skill_Retention_Score", "Burnout_Risk_Level"]].isna().sum().sum() == 0))

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print(f"{name}: {'PASS' if ok else 'FAIL'}")
    if failed:
        raise SystemExit(f"Validation failed: {failed}")
    print("All dashboard data checks passed.")


if __name__ == "__main__":
    main()
